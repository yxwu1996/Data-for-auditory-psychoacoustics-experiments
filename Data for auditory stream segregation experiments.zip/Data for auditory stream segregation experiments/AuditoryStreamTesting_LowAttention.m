clear;clc;
% clear sound
sr = 48000; % sound signal sampling frequency 
% f2 is fixed. 4st: 554.4 Hz  6st: 622.25 Hz  8st: 698.46 Hz  10st: 783.99 Hz
%             12st: 880 Hz   14st: 987.76 Hz 16st: 1108.7Hz   18st: 1244.5 Hz
%             20st: 1396.9 Hz
f2=440.01; f1= 1108.7; %A,B frequencies
d = 0.25; % A,B tones' dutrations
dt = 0.01; % transition interval's dutration
t = linspace(0,d,(1+sr*d)); %time series of f1 & f2 tones
tt = linspace(0,dt,(1+sr*dt));%time series of transition interval between A B tones
toneB = sin(2*pi*f1*t); % f1 tone's sound data 
toneA = cos(2*pi*f2*t); % f2 tone's sound data
toneBLANK=zeros(1,length(toneB)); %blank between sets of ABA
    
%   Each one set of ABA_ sequence is composed by 8 segments: 
%   Transition part (TR) between 0 (blank) and f2 tone (A), A tone, TR
%   between A and f2 (B) tones, B tone, Tr between B and A tones, A tone, TR
%   between A and 0. 

%Make sure that each segment of sound signal are connected smoothly.
for i=1:(length(tt))
    tonez(1,i)=sin(2*pi*tt(1,i)*(0+(0.5*tt(1,i)*(f2-0)/dt))); 
end

for i=(length(tt)):-1:1 % modify the transition part between 0,A at the ABA_ beginning 
    if tonez(1,i)<=1 && tonez(1,i)>=0.995 && tonez(1,i-1)<=tonez(1,i)
        tonez1=tonez(1:i);
        break
    end
end

if (f2*d-fix(f2*d)) <= 0.5 %determine if the end of tone2 (cosine) in the first half period of cosine
    for i=1:(length(tt))
        tonet(1,i)=cos(2*pi*tt(1,i)*(f2+(0.5*tt(1,i)*(f1-f2)/dt))); % transition part between tone1,tone2
    end
    for i=1:(length(tonet)-1) % find the junction of tone2's end with tonet's beginning 
        if abs(toneA(end)-tonet(1,i))<=abs(toneA(end)-tonet(1,i+1))
            tonet1=tonet(i:end);
            break
        end
    end
elseif (f2*d-fix(f2*d)) > 0.5
    for i=1:(length(tt))
        tonet(1,i)=cos(pi+2*pi*tt(1,i)*(f2+(0.5*tt(1,i)*(f1-f2)/dt))); % transition part between tone1,tone2
    end
    for i=1:(length(tonet)-1) % find the junction of tone2's end with tonet's beginning 
        if abs(toneA(end)-tonet(1,i))<=abs(toneA(end)-tonet(1,i+1))
            tonet1=tonet(i:end);
            break
        end
    end
end

for i=(length(tonet1)):-1:1 % determine the junction between transition part between f2,f1 and B tone
    if abs(tonet1(1,i-1)-0)>abs(tonet1(1,i)-0) && tonet1(1,i-1)<=tonet1(1,i)
        tonet1=tonet1(1:i-1);
        break
    end
end

tonetj=fliplr(tonet1);
if f1*d-fix(f1*d)<=0.25 || f1*d-fix(f1*d)>=0.75
    for i=1:(length(tonetj)-1)
        if abs(tonetj(1,i)-toneB(end))<=abs(tonetj(1,i+1)-toneB(end)) && tonetj(1,i)<=tonetj(1,i+1)
            tonet1r=tonetj((i+1):end);
            break
        end
    end
elseif 0.75>f1*d-fix(f1*d)>0.25
    for i=1:(length(tonetj)-1)
        if abs(tonetj(1,i)-toneB(end))<=abs(tonetj(1,i+1)-toneB(end)) && tonetj(1,i)>=tonetj(1,i+1)
            tonet1r=tonetj((i+1):end);
            break
            
        end
    end
end
Tone = [tonez1,toneA,tonet1,toneB,tonet1r,fliplr(toneA),fliplr(tonez1),toneBLANK];
ttt=0:(1/sr):(length(Tone)/sr); ttt=ttt(1:length(Tone));

%adjust the amplitude of tonez1 and fliplr(tonez1) to erease the vibration
%at the beginning and end of the BLANK
m=300; 
for i=1:(length(tonez1)+m)
    T(1,i)=0.05+ttt(1,i)^3*(0.95/((ttt(length(tonez1)+m))^3));
end
Tf=fliplr(T);
for i=1:(length(tonez1)+m)
    Tone(1,i)=Tone(1,i)*T(1,i);
end
k1=length([tonez1,toneA,tonet1,toneB,tonet1r,fliplr(toneA)])-m;
k2=length([tonez1,toneA,tonet1,toneB,tonet1r,fliplr(toneA),fliplr(tonez1)]);
for i=1:(length(tonez1)+m)
    Tone(1,i+k1)=Tone(1,i+k1)*Tf(1,i);
end

%Modulate the shape of the sound wave
Tonew=[tonez1,toneA,tonet1,toneB,tonet1r,fliplr(toneA),fliplr(tonez1)];
tttw=0:(1/sr):(length(Tonew)/sr); tttw=tttw(1:length(Tonew));
T=zeros(1,length(Tone));
for i=1:length(Tonew)
    T(1,i)=(1+sin(-0.5*pi+3*2*pi*tttw(1,i)/tttw(end)));
end
T=0.025+T*0.475;
Tone=Tone.*T;
    
Tone2=[Tone,Tone];
ttt2=0:(1/sr):(length(Tone2)/sr); ttt2=ttt2(1:length(Tone2));
Tones=repmat(Tone,1,2000); 
State=zeros(3,15);

Results=zeros(2,15);
S=randperm(15);
for i=1:15 % randomly set the sampling series of time (5*5+5*20+5*40)
    if S(1,i)<=5
        Results(1,i)=5;
    elseif S(1,i)<=10 && S(1,i)>5
        Results(1,i)=20;
    else
        Results(1,i)=40;
    end
end
disp(num2str(Results(1,:)));
dtsus = 0.15; 
ts = linspace(0,dtsus,(1+sr*dtsus)); 
ToneS = sin(2*pi*1000*ts);
for i=1:15 
    % capture the input if Int stream appears from the subjects when they lose their attention (PsychToolBox)
    % spacebar(keyCoed 32) for Int stream
    disp(['The ', num2str(i),'th test. ', char(10)', ' If you hear a relatively stable Seg stream, press any key', char(10)']);
    pause
    [KeylsDown,~,~,~]=KbCheck;
    if KeylsDown==1
        tsus=linspace(1,Results(1,i),sr*Results(1,i));
        ToneSus = zeros(1,length(tsus));
    end
    disp('Press Spacebar if hearing Int');
    pause
    [KeylsDown,Sec,KeyCode,deltaSecs]=KbCheck;
    if KeylsDown==1
        State(1,i)=find(KeyCode);
        State(2,i)=Sec;
        State(3,i)=deltaSecs;
    end
    disp(['Result recorded. The next test will begin.', char(13,10)'])
    pause(1)
end
clear sound
Results(2,:)=State(1,1:15);
Att5=0;Att20=0;Att40=0;
for i=1:15
    if Results(2,i)==32 && Results(1,i)==5
        Att5  = Att5+1;
    elseif Results(2,i)==32 && Results(1,i)==20
        Att20 = Att20+1;
    elseif Results(2,i)==32 && Results(1,i)==40
        Att40 = Att40+1;
    end
end

       
