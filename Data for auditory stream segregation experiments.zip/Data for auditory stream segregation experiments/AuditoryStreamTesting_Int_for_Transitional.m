clear;clc;
% clear sound
sr = 48000; % sound signal sampling frequency 
% f2 is fixed. 4st: 554.4 Hz  8st: 698.46 Hz  
%             12st: 880 Hz    16st: 1108.7Hz  
%             20st: 1396.9 Hz
f2= 440.01 ; f1= 880  ; %A,B frequencies
d = 0.25; % A,B tones' dutrations
dt = 0.01; % transition interval's dutration
t = linspace(0,d,(1+sr*d)); %time series of f1 & f2 tones
tt = linspace(0,dt,(1+sr*dt));%time series of transition interval between A B tones
toneB = sin(2*pi*f1*t); % f1 tone's sound data
toneA = cos(2*pi*f2*t); % f2 tone's sound data
toneBLANK=zeros(1,length(toneB)); %blank between sets of ABA
    
%   Each one set of ABA_ sequence is composed by 8 segments: 
%   Transition part (TR) between 0 (blank) and f2 tone (A), A tone, TR
%   between A and f2 (B) tones, B tone, Tr between B and A tones, A tone, TR
%   between A and 0. 

%Make sure that each segment of sound signal are connected smoothly.
for i=1:(length(tt))
    tonez(1,i)=sin(2*pi*tt(1,i)*(0+(0.5*tt(1,i)*(f2-0)/dt))); 
end

for i=(length(tt)):-1:1 % modify the transition part between 0,A at the ABA_ beginning 
    if tonez(1,i)<=1 && tonez(1,i)>=0.995 && tonez(1,i-1)<=tonez(1,i)
        tonez1=tonez(1:i);
        break
    end
end

if (f2*d-fix(f2*d)) <= 0.5 %determine if the end of tone2 (cosine) in the first half period of cosine
    for i=1:(length(tt))
        tonet(1,i)=cos(2*pi*tt(1,i)*(f2+(0.5*tt(1,i)*(f1-f2)/dt))); % transition part between tone1,tone2
    end
    for i=1:(length(tonet)-1) % find the junction of tone2's end with tonet's beginning 
        if abs(toneA(end)-tonet(1,i))<=abs(toneA(end)-tonet(1,i+1))
            tonet1=tonet(i:end);
            break
        end
    end
elseif (f2*d-fix(f2*d)) > 0.5
    for i=1:(length(tt))
        tonet(1,i)=cos(pi+2*pi*tt(1,i)*(f2+(0.5*tt(1,i)*(f1-f2)/dt))); % transition part between tone1,tone2
    end
    for i=1:(length(tonet)-1) % find the junction of tone2's end with tonet's beginning 
        if abs(toneA(end)-tonet(1,i))<=abs(toneA(end)-tonet(1,i+1))
            tonet1=tonet(i:end);
            break
        end
    end
end

for i=(length(tonet1)):-1:1 % determine the junction between transition part between f2,f1 and B tone
    if abs(tonet1(1,i-1)-0)>abs(tonet1(1,i)-0) && tonet1(1,i-1)<=tonet1(1,i)
        tonet1=tonet1(1:i-1);
        break
    end
end

tonetj=fliplr(tonet1);
if f1*d-fix(f1*d)<=0.25 || f1*d-fix(f1*d)>=0.75
    for i=1:(length(tonetj)-1)
        if abs(tonetj(1,i)-toneB(end))<=abs(tonetj(1,i+1)-toneB(end)) && tonetj(1,i)<=tonetj(1,i+1)
            tonet1r=tonetj((i+1):end);
            break
        end
    end
elseif 0.75>f1*d-fix(f1*d)>0.25
    for i=1:(length(tonetj)-1)
        if abs(tonetj(1,i)-toneB(end))<=abs(tonetj(1,i+1)-toneB(end)) && tonetj(1,i)>=tonetj(1,i+1)
            tonet1r=tonetj((i+1):end);
            break
            
        end
    end
end
Tone = [tonez1,toneA,tonet1,toneB,tonet1r,fliplr(toneA),fliplr(tonez1),toneBLANK];
ttt=0:(1/sr):(length(Tone)/sr); ttt=ttt(1:length(Tone));
  
%adjust the amplitude of tonez1 and fliplr(tonez1) to erease the vibration
%at the beginning and end of the BLANK
m=400; 
for i=1:(length(tonez1)+m)
    T(1,i)=0.05+ttt(1,i)^3*(0.95/((ttt(length(tonez1)+m))^3));
end
Tf=fliplr(T);
for i=1:(length(tonez1)+m)
    Tone(1,i)=Tone(1,i)*T(1,i);
end
k1=length([tonez1,toneA,tonet1,toneB,tonet1r,fliplr(toneA)])-m;
k2=length([tonez1,toneA,tonet1,toneB,tonet1r,fliplr(toneA),fliplr(tonez1)]);
for i=1:(length(tonez1)+m)
    Tone(1,i+k1)=Tone(1,i+k1)*Tf(1,i);
end

%Modulate the shape of the sound wave
Tonew=[tonez1,toneA,tonet1,toneB,tonet1r,fliplr(toneA),fliplr(tonez1)];
tttw=0:(1/sr):(length(Tonew)/sr); tttw=tttw(1:length(Tonew));
T=zeros(1,length(Tone));
for i=1:length(Tonew)
    T(1,i)=(1+sin(-0.5*pi+3*2*pi*tttw(1,i)/tttw(end)));
end
T=0.025+T*0.475;
Tone=Tone.*T;
    
Tone2=[Tone,Tone];
ttt2=0:(1/sr):(length(Tone2)/sr); ttt2=ttt2(1:length(Tone2));
Tones=repmat(Tone,1,1000); % nearly 4 minutes 
Tone2N=awgn(Tone2,20,'measured');
TonesN=awgn(Tones,20,'measured');
State=zeros(3,45);
%sound(Tones,sr);
%sound(TonesN,sr);
% clear sound


for i=1:3:45
    % capture the input from the subjects when they perceive a switching (PsychToolBox)
    % Seg A: �� ;  Seg B: �� ;  Int: �� ; Nothing: 0
    disp(['The ', num2str((i+2)/3),'th test��initial perception is��' char(10)']);
    pause
    [KeylsDown,Sec,KeyCode,deltaSecs]=KbCheck;
    if KeylsDown==1
        State(1,i)=find(KeyCode);
        State(2,i)=Sec;
        State(3,i)=deltaSecs;
        if State(1,i)==37
            disp('Seg A (Low frequency �� )')
        elseif State(1,i)==39
            disp('Seg B (High frequency ��)')
        end
    end
    disp(['Please try to slightly pay attention to another Seg sound, press �� when sensing Int, otherwise press 0' char(10)'])
    pause
    tic
    [KeylsDown,Sec,KeyCode,deltaSecs]=KbCheck;
    if KeylsDown==1
        State(1,i+1)=find(KeyCode);
        State(2,i+1)=Sec;
        State(3,i+1)=deltaSecs;
    end
    if State(1,i+1)==96
        disp(['Not perceiving Int as a transition state, proceed to the next test' char(10)'])
        toc
        State(1,i+2)=0;
        State(2,i+2)=0;
        State(3,i+2)=0;
    else
        disp(['perceived Int as a transition state' char(10)'])
        pause
        [KeylsDown,Sec,KeyCode,deltaSecs]=KbCheck;
        if KeylsDown==1
            State(1,i+2)=find(KeyCode);
            State(2,i+2)=Sec;
            State(3,i+2)=deltaSecs;
            if State(1,i+2)==37
                toc
                disp(['Transitioned from Int to Seg A (low frequency)' char(10)'])
            elseif State(1,i+2)==39
                toc
                disp(['Transitioned from Int to Seg B (High frequency)' char(10)'])
            end
        end
    
    end
end

Det=0; NoneDet=0;
DuDet=0;
result=zeros(2,15);
for i=3:3:45
    if State(1,i)==39 || State(1,i)==37
        Det=Det+1;
        DuDet=DuDet+State(3,i);
        result(1,i/3)=State(1,i);
        result(2,i/3)=State(3,i);
    else
        NoneDet=NoneDet+1;
    end
end

disp(['Number of detected transition Int: ',num2str(Det), ...
      '  Number of nothing: ',num2str(NoneDet), ...
      '  Mean Effective Transition Duraton: ',num2str(DuDet/15), ...
      '  Mean Transition Duraton: ',num2str(DuDet/Det)]);
